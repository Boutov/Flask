from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from config import host, user, password, db_name
import psycopg2
from flask_bcrypt import Bcrypt
from flask_migrate import Migrate

app = Flask(__name__)
app.secret_key = "supersecretkey"


def get_db_connection():
    return psycopg2.connect(
        host=host,
        user=user,
        password=password,
        database=db_name
    )

@app.route("/")
@app.route("/index")
def index():
    return render_template('index.html')

@app.route("/posts")
def posts():
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute("SELECT title, text FROM posts")
            posts = cursor.fetchall()  # Получаем все посты
    except Exception as e:
        flash(f"Database error: {e}", "danger")
        posts = []  # Пустой список, если произошла ошибка
    finally:
        if connection:
            connection.close()
    
    return render_template('posts.html', posts=posts)

@app.route("/authorization", methods=['POST', 'GET'])
def authorization():
    if request.method == 'POST':
        connection = None
        username = request.form['username']
        password = request.form['password']

        try:
            connection = get_db_connection()
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT * FROM users WHERE username = %s AND password = %s",
                    (username, password)
                )
                user = cursor.fetchone()

                if user:
                    return f"Welcome, {username}!"
                else:
                    flash("Invalid username or password", "danger")
        except Exception as e:
            flash(f"Database error: {e}", "danger")
        finally:
            if connection:
                connection.close()

    return render_template('authorization.html')

@app.route("/register", methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        connection = None
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        # Проверка пароля
        if password != confirm_password:
            return "Password error"
        
        try:
            connection = get_db_connection()
            with connection.cursor() as cursor:
                # SQL запрос на проверку существования пользователя
                cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
                user = cursor.fetchone()
                
                if user:
                    return f"User {username} already exists!"
                else:
                    # Запрос на добавление нового пользователя
                    cursor.execute(
                        "INSERT INTO users (username, password) VALUES (%s, %s)",
                        (username, password)
                    )
                    connection.commit()  # Сохраняем изменения в базе данных
                    
                    return redirect('/')
        
        except Exception as e:
            flash(f"Database error: {e}", "danger")
        
        finally:
            if connection:
                connection.close()

    return render_template('register.html')

@app.route("/create", methods=['POST', 'GET'])
def create():
    if request.method == 'POST':
        connection = None
        title = request.form['title']
        text = request.form['text']
        try:
            connection = get_db_connection()
            with connection.cursor() as cursor:
                    cursor.execute(
                        "INSERT INTO posts (title, text) VALUES (%s, %s)",
                        (title, text)
                    )
                    connection.commit()  # Сохраняем изменения в базе данных
        
        except Exception as e:
            flash(f"Database error: {e}", "danger")
        
        finally:
            if connection:
                connection.close()

    return render_template('create.html')

@app.route("/about")
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)